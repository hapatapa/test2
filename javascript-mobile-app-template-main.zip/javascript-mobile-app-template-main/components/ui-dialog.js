/* Bismillah */

/*

UI COMPONENT TEMPLATE
- You can customize, this template code as you need:


Started Date: 1 September 2022
Developer: Bugra Ozden
Email: bugra.ozden@gmail.com
Site: https://bug7a.github.io/javascript-mobile-app-template/


EXAMPLE: {javascript-mobile-app-template}/ui-dialog.htm


HOW TO USE:

dialog.create();
that.setType(dialog.MESSAGE) // EDIT, ADD,
that.setTitle("Some title");
that.getWidth();
that.getHeight();
that.setContent("Some messagge");
that.show();

dialog.show({
    title: "Some title"
    message: "No internet connection.", 
    backgroundColor: notice.colors.RED,
    textColor: "#141414"
})


*/

"use strict";
const dialog = {};

UIDialog.create = function() {
    
}